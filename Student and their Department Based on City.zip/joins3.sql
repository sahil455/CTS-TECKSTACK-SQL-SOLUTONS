select student_name, department_name from student S INNER JOIN department D
on S.department_id= D.department_id where city=  'Coimbatore' order by(student_name); 
