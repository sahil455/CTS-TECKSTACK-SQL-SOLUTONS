select hotel_id,hotel_name, count(hotel_id) as NO_OF_ORDERS from hotel_details join 
orders using(hotel_id)
group by hotel_id
having NO_OF_ORDERS>5
order by hotel_id;