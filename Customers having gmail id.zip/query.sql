select customer_id,customer_name,address,phone_no from customers
order by customer_id;
