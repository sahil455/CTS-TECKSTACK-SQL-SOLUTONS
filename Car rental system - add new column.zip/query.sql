Alter table Cars
add column Car_Regno varchar(10);