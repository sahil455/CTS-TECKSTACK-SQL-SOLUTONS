select order_id,customer_name,hotel_name,order_amount from hotel_details
join orders using (hotel_id)
join customers using (customer_id)
order by order_id;