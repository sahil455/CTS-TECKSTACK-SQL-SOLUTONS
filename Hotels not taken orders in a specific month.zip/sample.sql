/*select * from orders;*/
select distinct hotel_id,hotel_name,hotel_type from hotel_details 
where hotel_id not in
(
     select hotel_id from orders where
     order_date between '2019-05-01'and '2019-05-31'
)
order by hotel_id;