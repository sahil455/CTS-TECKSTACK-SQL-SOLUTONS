insert into department 
(Department_id, Department_name,Department_block_number)
values(1,'CSE',3);

insert into department
(Department_id,Department_name,Department_block_number)
values (2,'IT',3);

insert into department 
(Department_id, Department_name, Department_block_number)
values(3,'SE',3);