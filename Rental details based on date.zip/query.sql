select rental_id,car_id,customer_id,km_driven from rentals  
join cars  using (car_id)
join customers using (customer_id)
where return_date Between '2019-08-01' and '2019-08-31'
order by rental_id;