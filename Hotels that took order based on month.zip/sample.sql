select DISTINCT HT.hotel_id,hotel_name,rating from hotel_details HT
join orders O on HT.hotel_id=O.hotel_id where
month(order_date)=7
order by HT.hotel_id;
