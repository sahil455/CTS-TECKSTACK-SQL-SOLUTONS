select department_name from Department
where department_block_number=3 
order by(department_name);