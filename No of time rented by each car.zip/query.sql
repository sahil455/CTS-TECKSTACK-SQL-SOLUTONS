select car_id,count(customer_id) as NO_OF_TRIPS from rentals  
group by car_id
order by car_id;
