select concat(address, ", ",city) as Address from Student
order by (Address) desc;