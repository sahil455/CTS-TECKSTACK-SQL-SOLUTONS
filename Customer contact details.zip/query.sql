select customer_id,customer_name, coalesce(address,email_id,'NA') as CONTACT_DETAILS
from customers order by customer_id;